/**
 * In-memory performance model (timeline cues at whole-second times).
 * On disk the Director Open/Saves PFST (.pfs) — see show-table.js.
 * JSON here is only the live object plus patterns-catalog.json.
 */

/** Snap cue times to whole seconds (timeline granularity). */
export function quantizeTime(t) {
  const n = Math.round(Number(t));
  if (!Number.isFinite(n) || n < 0) return 0;
  return n;
}

export function emptyPerformance() {
  return {
    version: 1,
    id: "untitled-" + new Date().toISOString().slice(0, 10),
    title: "Untitled",
    utcStart: "",
    channel: 0,
    length: 60,
    loop: false,
    patternsZip: "",
    patternsZipSha256: "",
    required: ["Origin"],
    timeline: [
      { t: 0, pattern: "Origin" },
      { t: 0, param: [500, 500, 500, 500] }
    ]
  };
}

export function normalizePerformance(raw) {
  const base = emptyPerformance();
  if (!raw || typeof raw !== "object") return base;
  const out = { ...base, ...raw };
  out.version = Number(out.version) || 1;
  out.id = String(out.id || base.id);
  out.title = String(out.title || base.title);
  out.utcStart = out.utcStart == null ? "" : String(out.utcStart);
  out.channel = Number(out.channel) || 0;
  out.length = Math.max(1, Math.round(Number(out.length) || 60));
  out.loop = !!out.loop;
  out.patternsZip = out.patternsZip == null ? "" : String(out.patternsZip);
  out.patternsZipSha256 =
    out.patternsZipSha256 == null ? "" : String(out.patternsZipSha256);
  out.required = Array.isArray(out.required)
    ? out.required.map(String)
    : base.required;
  out.timeline = Array.isArray(out.timeline)
    ? out.timeline
        .map(normalizeCue)
        .filter(Boolean)
        .sort(compareCues)
    : base.timeline;
  return out;
}

function cueKindOrder(cue) {
  if (cue.pattern != null) return 0;
  if (cue.param) return 1;
  if (cue.message != null) return 2;
  return 3;
}

export function compareCues(a, b) {
  if (a.t !== b.t) return a.t - b.t;
  return cueKindOrder(a) - cueKindOrder(b);
}

/**
 * Parse param field into length-4 sparse array (null = not set on this cue).
 * Accepts [n,n,n,n], sparse array with nulls, or { "1": n, "2": n } (1-based).
 */
export function parseParamField(raw) {
  const out = [null, null, null, null];
  if (Array.isArray(raw)) {
    for (let i = 0; i < 4 && i < raw.length; i++) {
      if (raw[i] == null || raw[i] === "") continue;
      out[i] = clamp1000(raw[i]);
    }
  } else if (raw && typeof raw === "object") {
    for (const [k, v] of Object.entries(raw)) {
      if (v == null || v === "") continue;
      let i = Number(k);
      if (!Number.isFinite(i)) continue;
      if (i >= 1 && i <= 4) i -= 1;
      else if (i < 0 || i > 3) continue;
      out[i] = clamp1000(v);
    }
  } else {
    return null;
  }
  if (out.every((x) => x == null)) return null;
  return out;
}

/** Merge sparse patches; values from `patch` win when non-null. */
export function mergeParamSparse(base, patch) {
  const out = [null, null, null, null];
  for (let i = 0; i < 4; i++) {
    if (patch && patch[i] != null) out[i] = clamp1000(patch[i]);
    else if (base && base[i] != null) out[i] = clamp1000(base[i]);
  }
  return out.every((x) => x == null) ? null : out;
}

/** JSON-facing param: full array if all set, else 1-based object. */
export function serializeParam(param) {
  if (!param) return undefined;
  const dense = param.every((v) => v != null);
  if (dense) return param.map((n) => clamp1000(n));
  const obj = {};
  for (let i = 0; i < 4; i++) {
    if (param[i] != null) obj[String(i + 1)] = clamp1000(param[i]);
  }
  return obj;
}

export function serializePerformance(perf) {
  const p = normalizePerformance(perf);
  return {
    version: p.version,
    id: p.id,
    title: p.title,
    utcStart: p.utcStart,
    channel: p.channel,
    length: p.length,
    loop: p.loop,
    patternsZip: p.patternsZip,
    patternsZipSha256: p.patternsZipSha256,
    required: p.required,
    timeline: (p.timeline || []).map((cue) => {
      const out = { t: quantizeTime(cue.t) };
      if (cue.pattern != null) out.pattern = cue.pattern;
      if (cue.message != null) out.message = cue.message;
      if (cue.param) {
        out.param = serializeParam(cue.param);
      }
      return out;
    })
  };
}

function normalizeCue(cue) {
  if (!cue || typeof cue !== "object") return null;
  const t = quantizeTime(cue.t);
  const out = { t };
  if (cue.pattern != null && String(cue.pattern).length) {
    out.pattern = String(cue.pattern);
  }
  const param = parseParamField(cue.param);
  if (param) {
    out.param = param;
  }
  if (cue.message != null) {
    out.message = String(cue.message);
  }
  if (out.pattern == null && out.param == null && out.message == null) {
    return null;
  }
  return out;
}

export function clamp1000(n) {
  let v = Math.round(Number(n));
  if (!Number.isFinite(v)) v = 500;
  if (v < 0) v = 0;
  if (v > 1000) v = 1000;
  return v;
}

/**
 * Display names actually planted on the timeline (not the Required shortlist).
 */
export function timelinePatternNames(perf) {
  const seen = Object.create(null);
  const out = [];
  for (const cue of perf.timeline || []) {
    const name = String(cue.pattern || "").trim();
    if (!name) continue;
    const key = name.toLowerCase();
    if (seen[key]) continue;
    seen[key] = true;
    out.push(name);
  }
  return out;
}

/**
 * Timeline extent in seconds. Authoring length wins; never shorter than last cue.
 */
export function durationOf(perf) {
  let maxCue = 0;
  for (const c of perf.timeline || []) {
    if (c.t > maxCue) maxCue = c.t;
  }
  const len = Math.max(1, Math.round(Number(perf.length) || 60));
  return Math.max(len, maxCue);
}

/** Clamp a time into [0, duration]. */
export function clampToDuration(perf, t) {
  const d = durationOf(perf);
  const n = quantizeTime(t);
  if (n > d) return d;
  return n;
}

/** Last defined value for a channel at or before t (step / hold). */
function paramChannelAt(cues, channel, t) {
  let prev = null;
  for (const c of cues) {
    if (c.t > t) break;
    if (!c.param || c.param[channel] == null) continue;
    prev = c;
  }
  if (prev) return prev.param[channel];
  // Before first keyframe: use first future value for that channel, else 500
  for (const c of cues) {
    if (c.param && c.param[channel] != null) return c.param[channel];
  }
  return 500;
}

/**
 * Composed snapshot at time t: fold all cues with cue.t <= t.
 * Pattern/message last-write-wins; each param channel last-write-wins.
 */
export function stateAt(perf, t) {
  const cues = perf.timeline || [];
  let pattern = "";
  let message = "";

  for (const c of cues) {
    if (c.t > t) break;
    if (c.pattern != null) pattern = c.pattern;
    if (c.message != null) message = c.message;
  }

  const param = [
    paramChannelAt(cues, 0, t),
    paramChannelAt(cues, 1, t),
    paramChannelAt(cues, 2, t),
    paramChannelAt(cues, 3, t)
  ];

  return { pattern, message, param, t };
}

/** Short label for cue list / chips. */
export function formatParamSparse(param) {
  if (!param) return "";
  const parts = [];
  for (let i = 0; i < 4; i++) {
    if (param[i] != null) parts.push("P" + (i + 1) + "=" + param[i]);
  }
  return parts.join(" ");
}
